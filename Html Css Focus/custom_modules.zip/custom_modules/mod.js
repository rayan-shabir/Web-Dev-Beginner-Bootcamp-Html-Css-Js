console.log("This is mod.js");

function average(arr) {
    let sum = 0;

    arr.forEach(element =>{
        sum += element;
    });

    return sum/arr.length;
}

// --> Exporting 1 function
// module.exports = average;

// --> Exporting group of Objects
module.exports = {
    avg: average,
    name: "Rayan",
    repo: "GitHub"
}

// --> Exporting 1 single element
// module.exports.name = "Rayan";