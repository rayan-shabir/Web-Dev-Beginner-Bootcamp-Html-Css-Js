const average = require("mod");
// console.log(average([3, 4, 5]));