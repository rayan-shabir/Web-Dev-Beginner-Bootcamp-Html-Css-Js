let order = (my_prod_call) => {
    console.log("Order is placed, Please call Production");

    my_prod_call();
}

let production = ()=> {
    console.log("Production has started");
}

order(production);