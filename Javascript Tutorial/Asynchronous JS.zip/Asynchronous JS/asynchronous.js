console.log(" I ");

console.log(" eat ");

setTimeout(()=>{
    console.log(" Ice Cream ");
}, 4000);

console.log(" with a ");

console.log(" spoon ");