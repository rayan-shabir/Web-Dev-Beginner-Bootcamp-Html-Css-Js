// Use of Await

// Object
let stocks = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    Liquid: ["water", "ice"],
    Holder: ["cone", "cup", "stick"],
    Topping: ["chocolate", "peanuts"]
}


let kitchen = () => {
    return new Promise((resolve, reject)=> {
        setTimeout(()=> {
            resolve(console.log("Which topping do you like?"));
        }, 2000);
    });
}

let order = async () => {
    console.log("A");
    console.log("B");

    await kitchen();

    console.log("C");
    console.log("D");
}

order();

console.log("Doing the dishes...");

console.log("Cleaning the tables...");

