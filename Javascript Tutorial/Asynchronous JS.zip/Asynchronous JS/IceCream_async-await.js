// Ice Cream async / await

// Object
let stocks = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    Liquid: ["water", "ice"],
    Holder: ["cone", "cup", "stick"],
    Topping: ["chocolate", "peanuts"]
}

let is_shop_open = true;

function time(ms) {
    return new Promise((resolve, reject)=> {
        if(is_shop_open) {
            setTimeout(resolve, ms);
        } else {
            reject(console.log("Shop was closed"));
        }
    });
}

async function kitchen() {
    try {
        await time(2000);
        console.log(`${stocks.Fruits[0]} was selected`);

        await time(0);
        console.log("Production has started");

        await time(2000);
        console.log("Fruit has been chopped");

        await time(1000);
        console.log(`${stocks.Liquid[0]} and ${stocks.Liquid[1]} was added`);

        await time(1000);
        console.log("Machine was started");

        await time(2000);
        console.log(`Ice cream was placed on ${stocks.Holder[0]}`);

        await time(3000);
        console.log(`${stocks.Topping[0]} was added`);

        await time(2000);
        console.log("Ice Cream was served");
    }
    catch (error) {
        console.log("Customer Left", error);
    }
    finally {
        console.log("Day Ended, Shop is closed");
    }
}

kitchen();