console.log(" I ");

console.log(" eat ");

console.log(" Ice Cream ");

console.log(" with a ");

console.log(" spoon ");