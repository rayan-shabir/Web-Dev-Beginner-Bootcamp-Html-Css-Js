// THIS IS A CALL BACK HELL 

// Object
let stocks = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    Liquid: ["water", "ice"],
    Holder: ["cone", "cup", "stick"],
    Topping: ["chocolate", "peanuts"]
}

// stocks.Fruits[0];

let order = (Fruit_name, call_prod) => {
    setTimeout(() => {
        console.log(`${stocks.Fruits[Fruit_name]} was selected`);

        call_prod();
    }, 2000);
}

let production = () => {
    console.log("Production has started");
    setTimeout(() => {
        console.log("Fruits has been chopped");

        setTimeout(() => {
            console.log(`${stocks.Liquid[0]} and ${stocks.Liquid[1]} was added`);

            setTimeout(() => {
                console.log("Machine was started");

                setTimeout(() => {
                    console.log(`Ice Cream was placed on ${stocks.Holder[1]}`);

                    setTimeout(() => {
                        console.log(`${stocks.Topping[0]} was added`);

                        setTimeout(() => {
                            console.log("Ice Cream was served");
                        }, 2000);
                    }, 3000);
                }, 2000);
            }, 1000);
        }, 1000);
    }, 2000);
}

order(0, production);