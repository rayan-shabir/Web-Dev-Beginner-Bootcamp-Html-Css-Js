// Async / Await

// Object
let stocks = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    Liquid: ["water", "ice"],
    Holder: ["cone", "cup", "stick"],
    Topping: ["chocolate", "peanuts"]
}


async function order() {
    try {
        await ABC;
    } 
    catch(error) {
        console.log("ABC does not exists", error);
    }
    finally {
        console.log("It runs anyways");
    }
}

order()

.then(()=>{
    console.log("Then is run");
})