// Promises

// Object
let stocks = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    Liquid: ["water", "ice"],
    Holder: ["cone", "cup", "stick"],
    Topping: ["chocolate", "peanuts"]
}

let is_shop_open = false;

let order = (time, work) => {
    return new Promise((resolve, reject)=> {
        if(is_shop_open) {
            setTimeout(()=> {
                resolve(work());
            }, time);
        } else {
            reject(console.log("Shop is closed"));
        }
    });
}

order(2000, ()=> {
    console.log(`${stocks.Fruits[0]} was selected`);
})

.then(()=>{
    return order(0, ()=>console.log("Production has started"));
})

.then(()=> {
    return order(2000, ()=>console.log("Fruits has been chopped"));
})

.then(()=> {
    return order(1000, ()=> {
        console.log(`${stocks.Liquid[0]} and ${stocks.Liquid[1]} was added`);
    })
})

.then(()=> {
    return order(1000, ()=> console.log("Machine was started"));
})

.then(()=> {
    return order(2000, ()=>console.log(`Ice crfeam was placed on ${stocks.Holder[0]}`))
})

.then(()=> {
    return order(3000, ()=>console.log(`${stocks.Topping[0]} was added`))
})

.then(()=> {
    return order(2000, ()=> {
        console.log("Ice cream was served");
    })
})

.catch(()=> {
    console.log("Customer left");
})

.finally(()=> {
    console.log("Day Ended, shop was closed");
})